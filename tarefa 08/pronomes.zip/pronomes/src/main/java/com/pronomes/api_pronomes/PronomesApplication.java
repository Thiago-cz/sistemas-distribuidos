package com.pronomes.api_pronomes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PronomesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PronomesApplication.class, args);
	}

}
